class NoTokenError(Exception):
    """Line notify token is not set."""