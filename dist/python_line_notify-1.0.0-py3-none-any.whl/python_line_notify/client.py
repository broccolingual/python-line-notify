from python_line_notify.utils import get_image_size, is_jpg, is_url
import requests

from .exceptions import *

LINE_API_URL = 'https://notify-api.line.me/api/notify'

class Client(object):
    def __init__(self, token=None):
        self.token = token

    def set_token(self, token):
        self.token = token
        return self

    def _get_headers(self):
        if self.token is not None:
            return {'Authorization': f'Bearer {self.token}'}
        else:
            raise NoTokenError

    def send(self, content: str=None, image: str=None):
        if content is not None and 1 <= len(content) <= 1000:
            if image is not None:
                if is_url(image) is True and is_jpg(image) is True:
                    width, height = get_image_size(image)
                    if width <= 240 and height <= 240: # imageThumbnail - max 240px x 240px
                        imageThumbnail = {'imageThumbnail': image}
                        r = requests.post(LINE_API_URL, headers=self._get_headers(), data={'message': {content}}, files=imageThumbnail)
                    elif width <= 2048 and height <= 2048: # imageFullsize - max 2048px x 2048px
                        imageFullsize = {'imageFullsize': image}
                        r = requests.post(LINE_API_URL, headers=self._get_headers(), data={'message': {content}}, files=imageFullsize)
                elif is_url is False:
                    binary_image = open(image, mode='rb')
                    try:
                        imageFile = {'imageFile': binary_image}
                        r = requests.post(LINE_API_URL, headers=self._get_headers(), data={'message': {content}}, files=imageFile)
                    except Exception:
                        pass
                    finally:
                        binary_image.close()
            else:
                r = requests.post(LINE_API_URL, headers=self._get_headers(), data={'message': {content}})